/**
	This class represents a writing utensil for an art supply store.
	@author Connor Wilson
	@author Ethan McCarthy 3573807
*/

public class WritingUtensil{
	
	//Instance variables

	//Contains colour of the utensil
	private String colour;

	//Contains the type of the utensil 
	//For example: "Marker", "Pencil", or "Pen"
	private String type;

	//Contains the price of the utensil
	private double price;

	//The number of utensil units sold
	private int sold;

	//The brand of the utensil
	private String brand;


	//The constructor creates a new WritingUtensil object and initializes the
	//instance variables.
	public WritingUtensil(String colourIn, String typeIn, double priceIn, String brandIn){
		colour = colourIn;
		type = typeIn;
		price = priceIn;
		sold = 0; //Starts with zero sales
		brand = brandIn;
		
	}

	//This is a method that we can call on a WritingUtensil object
	//(Specifically, it is an accessor method). This method
	//creates and returns a String containing all the information
	//about the state of the object.
	public String toString(){
		return "Colour: " + colour 
				+ "\n\tType: " + type
				+ "\n\tPrice: $"+ price
				+ "\n\tTotal Sales Amount: $" + (price * sold) 
				+ "\n\tBrand: " + brand;
	}

	//adds to the number of units sold when called on in the writingUtensilDriver program
	public String recordUnitsSold(int soldIn){
		sold += soldIn; //adds together all of the soldIn inputs to create a final number
		return "";
	}

	



}