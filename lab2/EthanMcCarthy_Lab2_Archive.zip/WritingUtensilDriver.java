/**
	Example of a driver class.
	This driver creates and tests WritingUtensil objects.
	@author Connor Wilson
	@author Ethan McCarthy 3573807
*/
public class WritingUtensilDriver {

	public static void main (String[] args) {
	
		//Creates 4 WritingUtensil objects
		WritingUtensil utensil1 = new WritingUtensil("Black", "Marker", 1.59, "Hilroy");
		WritingUtensil utensil2 = new WritingUtensil("Grey", "Pencil", 0.49, "Bic");
		WritingUtensil utensil3 = new WritingUtensil("Red", "Pen", 1.19, "Paper Mate");
		WritingUtensil utensil4 = new WritingUtensil("Pink","Pen", 1.99, "Ardene");
	

		//4 statements to add to the sold variable 
		System.out.println(utensil1.recordUnitsSold(15));
		System.out.println(utensil2.recordUnitsSold(19));
		System.out.println(utensil3.recordUnitsSold(25));
		System.out.println(utensil1.recordUnitsSold(25));
		
		
		
		//I can print my WritingUtensils to confirm they 
		//were created properly
		System.out.println("utensil1: " + utensil1.toString());
		System.out.println("utensil2: " + utensil2.toString());
		System.out.println("utensil3: " + utensil3.toString());
		System.out.println("utensil4: " + utensil4.toString());

	}

}