/**
 * Test class for the Saddle and Horse classes 
 * @author Ethan McCarthy 3573807
 */

public class Lab3TestDriver{

    public static void main(String[] args){

        Saddle Plexiglass = new Saddle("Plexiglass", 67.25, 20.00);
        Saddle Leather = new Saddle("Leather", 63.5, 15.50);
        Saddle Wood = new Saddle("Pressed Wood", 53.5, 28.75);

        Horse Carrots = new Horse("Carrots", 3, 56.55, Plexiglass);
        Horse Betty = new Horse("Betty", 5, 65.33, Leather);
        Horse Maribelle = new Horse("Maribelle", 3, 75.50, Wood);


        Maribelle.setCostToRent(85.50);

        Betty.incrementAge();
        Betty.setCostToRent(75.75);

        Saddle Iron = new Saddle("Iron", 67.25, 24.00);
        Carrots.setSaddle(Iron);

        System.out.println(Carrots.getInfo());
        System.out.println("Total Lesson Cost: " + Carrots.getTotalLessonCost());

        System.out.println(Betty.getInfo());
        System.out.println("Total Lesson Cost: " + Betty.getTotalLessonCost()); 

        System.out.println(Maribelle.getInfo());
        System.out.println("Total Lesson Cost: " + Maribelle.getTotalLessonCost());

    }


}