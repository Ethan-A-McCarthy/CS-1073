/**
@author Ethan McCarthy 3573807
*/


public class Horse{

	//the name of the horse 
	private String name;

	//the age of the horse 
	private int age;

	//the cost to rent the horse
	private double costToRent;

	//the saddle that is on the horse 
	private Saddle saddle;


	/**
	 * the constructor class to make a horse and initialize the variables
	 * @param nameIn the name
	 * @param ageIn the age
	 * @param costToRentIn the cost to rent
	 * @param saddleIn the saddle 
	 */
	public Horse(String nameIn, int ageIn, double costToRentIn, Saddle saddleIn){
		name = nameIn;
		age = ageIn;
		costToRent = costToRentIn;
		saddle = saddleIn;

	}

	/**
	 * mutator class to make a new name for a horse
	 * @param nameIn new name
	 * @return the new given name 
	 */
	public String setName(String nameIn){
		name = nameIn;
		return name;
	}
	
	//mutator method to increase the age of the horse by one year
	public void incrementAge(){
		age += 1; 	
	}
	
	/**
	 * mutator method to set a new cost to rent 
	 * @param costToRentIn the new cost to rent 
	 * @return the new cost to rent 
	 */
	public double setCostToRent(double costToRentIn){
		costToRent = costToRentIn;
		return costToRent;
	}
	
	/**
	 * mutator method to assign a new saddle to the horse 
	 * @param saddleIn the new saddle
	 * @return new saddle 
	 */
	public Saddle setSaddle(Saddle saddleIn){
		saddle = saddleIn;
		return saddle;
	}

	/**
	 * method to retreive the info about the horse
	 * @return the info about the horse 
	 */
	public String getInfo(){
		return name + " (age: " + age + ")\n\tSaddle: " + saddle.getMaterial() + " (width: " + saddle.getWidth() + " cm)";
	}

	/**
	 * method to retrieve the total cost for the lesson 
	 * @return the total cost
	 */
	public double getTotalLessonCost(){
		double totalCost = 17.50 + costToRent + saddle.getCost();
		return totalCost;
	}

	


}

